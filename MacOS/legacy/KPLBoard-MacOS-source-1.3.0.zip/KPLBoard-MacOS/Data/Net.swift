import Foundation

/// 统一的网络层。所有上游请求都走这里，便于统一 UA / 超时 / 错误处理。
enum Net {
    // macOS 版改发 Mac Safari UA（iPad 版为 iPad UA）；上游据此返回桌面版页面结构
    static let ua = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15"

    enum NetError: Error, LocalizedError {
        case badStatus(Int)
        case notJSON
        case upstream(String)

        var errorDescription: String? {
            switch self {
            case .badStatus(let c): return "上游返回 \(c)"
            case .notJSON: return "响应不是合法 JSON"
            case .upstream(let m): return m
            }
        }
    }

    private static func session(timeout: TimeInterval) -> URLSession {
        let cfg = URLSessionConfiguration.ephemeral
        cfg.timeoutIntervalForRequest = timeout
        cfg.timeoutIntervalForResource = timeout
        cfg.httpAdditionalHeaders = ["User-Agent": ua]
        return URLSession(configuration: cfg)
    }

    /// POST application/x-www-form-urlencoded，返回 JSON 对象
    static func postForm(_ url: String,
                         form: [String: String],
                         headers: [String: String] = [:],
                         timeout: TimeInterval = 15) async throws -> [String: Any] {
        var comps = URLComponents()
        comps.queryItems = form.map { URLQueryItem(name: $0.key, value: $0.value) }
        let body = (comps.percentEncodedQuery ?? "").data(using: .utf8) ?? Data()

        var req = URLRequest(url: URL(string: url)!)
        req.httpMethod = "POST"
        req.httpBody = body
        req.setValue("application/x-www-form-urlencoded; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }

        let (data, resp) = try await session(timeout: timeout).data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw NetError.badStatus((resp as? HTTPURLResponse)?.statusCode ?? -1)
        }
        guard let json = try? JSONSerialization.jsonObject(with: data), let obj = json as? [String: Any] else {
            throw NetError.notJSON
        }
        return obj
    }

    /// POST application/x-www-form-urlencoded，返回原始文本（archive 通道返回 HTML）
    static func postFormText(_ url: String,
                             form: [String: String],
                             headers: [String: String] = [:],
                             timeout: TimeInterval = 20) async throws -> String {
        var comps = URLComponents()
        comps.queryItems = form.map { URLQueryItem(name: $0.key, value: $0.value) }
        let body = (comps.percentEncodedQuery ?? "").data(using: .utf8) ?? Data()

        var req = URLRequest(url: URL(string: url)!)
        req.httpMethod = "POST"
        req.httpBody = body
        req.setValue("application/x-www-form-urlencoded; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }

        let (data, resp) = try await session(timeout: timeout).data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw NetError.badStatus((resp as? HTTPURLResponse)?.statusCode ?? -1)
        }
        if let s = String(data: data, encoding: .utf8) { return s }
        // 玩加 archive 通道偶发 GBK 编码，回退一次
        let gb = String.Encoding(
            rawValue: CFStringConvertEncodingToNSStringEncoding(
                CFStringEncoding(CFStringEncodings.GB_18030_2000.rawValue)))
        return String(data: data, encoding: gb) ?? ""
    }

    /// POST JSON，返回 JSON 对象（KPL 官方接口）
    static func postJSON(_ url: String,
                         body: [String: Any],
                         headers: [String: String] = [:],
                         timeout: TimeInterval = 12) async throws -> [String: Any] {
        var req = URLRequest(url: URL(string: url)!)
        req.httpMethod = "POST"
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }

        let (data, resp) = try await session(timeout: timeout).data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw NetError.badStatus((resp as? HTTPURLResponse)?.statusCode ?? -1)
        }
        guard let json = try? JSONSerialization.jsonObject(with: data), let obj = json as? [String: Any] else {
            throw NetError.notJSON
        }
        return obj
    }

    /// GBK / GB18030 解码（官网英雄详情页是 GBK 页面）
    static func decodeGBK(_ data: Data) -> String {
        let enc = String.Encoding(
            rawValue: CFStringConvertEncodingToNSStringEncoding(
                CFStringEncoding(CFStringEncodings.GB_18030_2000.rawValue)))
        return String(data: data, encoding: enc) ?? String(data: data, encoding: .utf8) ?? ""
    }

    /// GET 任意 JSON（数组或对象）。官方 herolist/item/ming 接口顶层是数组。
    static func getJSONAny(_ url: String,
                           headers: [String: String] = [:],
                           timeout: TimeInterval = 15) async throws -> Any {
        var req = URLRequest(url: URL(string: url)!)
        req.httpMethod = "GET"
        req.setValue("*/*", forHTTPHeaderField: "Accept")
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }
        let (data, resp) = try await session(timeout: timeout).data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw NetError.badStatus((resp as? HTTPURLResponse)?.statusCode ?? -1)
        }
        return try JSONSerialization.jsonObject(with: data)
    }

    /// GET 原始字节 + 响应对象。图片可达性探测、GBK 页面抓取、取 Set-Cookie 都用它。
    /// 返回 HTTPURLResponse 而不仅是头字典：`allHeaderFields` 的 value 可能是数组，
    /// 直接 as? [String: String] 会整体失败，用 `value(forHTTPHeaderField:)` 才稳。
    static func getRaw(_ url: String,
                       headers: [String: String] = [:],
                       timeout: TimeInterval = 15) async throws -> (Data, Int, HTTPURLResponse?) {
        var req = URLRequest(url: URL(string: url)!)
        req.httpMethod = "GET"
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }
        let (data, resp) = try await session(timeout: timeout).data(for: req)
        return (data, (resp as? HTTPURLResponse)?.statusCode ?? -1, resp as? HTTPURLResponse)
    }

    /// GET 文本（UTF-8 优先，用于官网公告的 JS literal 接口）
    static func getText(_ url: String,
                        headers: [String: String] = [:],
                        timeout: TimeInterval = 15) async throws -> String {
        var req = URLRequest(url: URL(string: url)!)
        req.httpMethod = "GET"
        req.setValue("*/*", forHTTPHeaderField: "Accept")
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }
        let (data, resp) = try await session(timeout: timeout).data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw NetError.badStatus((resp as? HTTPURLResponse)?.statusCode ?? -1)
        }
        return String(data: data, encoding: .utf8) ?? decodeGBK(data)
    }

    /// 带自定义头 + 返回响应头的 POST（玩加 /ajax/stats/list 需要 Cookie 与 X-CSRF-Token，
    /// 首次握手还要从 Set-Cookie 里取 wanplus_token 做 time33 签名）
    static func postFormDetailed(_ url: String,
                                 form: [String: String],
                                 headers: [String: String] = [:],
                                 timeout: TimeInterval = 20) async throws -> (Any, HTTPURLResponse?) {
        var comps = URLComponents()
        comps.queryItems = form.map { URLQueryItem(name: $0.key, value: $0.value) }
        let body = (comps.percentEncodedQuery ?? "").data(using: .utf8) ?? Data()

        var req = URLRequest(url: URL(string: url)!)
        req.httpMethod = "POST"
        req.httpBody = body
        req.setValue("application/x-www-form-urlencoded; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }

        // 关掉自动 cookie 处理：签名要用请求返回的原始 Set-Cookie，且 cookie 由我们手动带
        let cfg = URLSessionConfiguration.ephemeral
        cfg.timeoutIntervalForRequest = timeout
        cfg.timeoutIntervalForResource = timeout
        cfg.httpAdditionalHeaders = ["User-Agent": ua]
        cfg.httpShouldSetCookies = false
        cfg.httpCookieAcceptPolicy = .never
        let sess = URLSession(configuration: cfg)

        let (data, resp) = try await sess.data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw NetError.badStatus((resp as? HTTPURLResponse)?.statusCode ?? -1)
        }
        let json = try JSONSerialization.jsonObject(with: data)
        return (json, http)
    }

    /// GET JSON（PandaScore 聚合源）
    static func getJSON(_ url: String, timeout: TimeInterval = 12) async throws -> [String: Any] {
        var req = URLRequest(url: URL(string: url)!)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, resp) = try await session(timeout: timeout).data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw NetError.badStatus((resp as? HTTPURLResponse)?.statusCode ?? -1)
        }
        guard let json = try? JSONSerialization.jsonObject(with: data), let obj = json as? [String: Any] else {
            throw NetError.notJSON
        }
        return obj
    }
}

// MARK: - 任意 JSON 值的安全取值

extension Dictionary where Key == String {
    func num(_ k: String) -> Int {
        if let n = self[k] as? NSNumber { return n.intValue }
        if let s = self[k] as? String { return Int(s) ?? 0 }
        if let d = self[k] as? Double { return Int(d) }
        return 0
    }
    func str(_ k: String) -> String {
        if let s = self[k] as? String { return s }
        if let n = self[k] as? NSNumber { return String(n.intValue) }
        return ""
    }
    func boolish(_ k: String) -> Bool {
        if let b = self[k] as? Bool { return b }
        if let n = self[k] as? NSNumber { return n.intValue != 0 }
        if let s = self[k] as? String { return s == "1" || s.lowercased() == "true" }
        return false
    }
    func dict(_ k: String) -> [String: Any]? { self[k] as? [String: Any] }
    func arr(_ k: String) -> [[String: Any]]? { self[k] as? [[String: Any]] }
}
